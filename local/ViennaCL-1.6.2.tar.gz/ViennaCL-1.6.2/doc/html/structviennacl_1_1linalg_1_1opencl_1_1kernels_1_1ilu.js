var structviennacl_1_1linalg_1_1opencl_1_1kernels_1_1ilu =
[
    [ "init", "structviennacl_1_1linalg_1_1opencl_1_1kernels_1_1ilu.html#a94459380f1ee4d134117efbf6120b4a2", null ],
    [ "program_name", "structviennacl_1_1linalg_1_1opencl_1_1kernels_1_1ilu.html#a3c7d96fb86b19c0aeb671486e3a30c9f", null ]
];