var classviennacl_1_1cuda__not__available__exception =
[
    [ "cuda_not_available_exception", "classviennacl_1_1cuda__not__available__exception.html#a941a849d4b445e91c19f14cb3e7d1419", null ],
    [ "~cuda_not_available_exception", "classviennacl_1_1cuda__not__available__exception.html#a8e4a228218ec828c3d74facbd8388df0", null ],
    [ "what", "classviennacl_1_1cuda__not__available__exception.html#a94c488fd1c10322c3f594bdf7946a859", null ]
];