var namespaceviennacl_1_1linalg_1_1detail_1_1fft =
[
    [ "next_power_2", "namespaceviennacl_1_1linalg_1_1detail_1_1fft.html#a26cc8c388060b9785276efa43df28350", null ],
    [ "num_bits", "namespaceviennacl_1_1linalg_1_1detail_1_1fft.html#a4b510a646bf1fa6cf85b8df1d37e696f", null ],
    [ "MAX_LOCAL_POINTS_NUM", "namespaceviennacl_1_1linalg_1_1detail_1_1fft.html#a4e9922fb38a92859cebcb2d4366cac40", null ]
];