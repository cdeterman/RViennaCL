var fft__2d_8cpp =
[
    [ "testData", "structtest_data.html", "structtest_data" ],
    [ "input_function_ptr", "fft__2d_8cpp.html#a4b189d809e837b0a80d17a81f0649314", null ],
    [ "ScalarType", "fft__2d_8cpp.html#ad5c19ca4f47d3f8ec21232a5af2624e5", null ],
    [ "test_function_ptr", "fft__2d_8cpp.html#ad431337acacff9e06c1286095e78f8ac", null ],
    [ "copy_matrix_to_vector", "fft__2d_8cpp.html#a4461a05ba16b9052cf36f4752c63619e", null ],
    [ "copy_vector_to_matrix", "fft__2d_8cpp.html#a40b89a65d3390cf44a03717ee53eedca", null ],
    [ "diff", "fft__2d_8cpp.html#a3042870eb8881681860b088156ccf079", null ],
    [ "diff_max", "fft__2d_8cpp.html#aadad85fa5cbf31466487bb0585d1a769", null ],
    [ "fft_2d_1arg", "fft__2d_8cpp.html#afc07a94f6f8fca89904a2b6a89bc4e14", null ],
    [ "fft_2d_2arg", "fft__2d_8cpp.html#a05ddc634f34ae8fb86372ff8626a059f", null ],
    [ "main", "fft__2d_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "read_matrices_pair", "fft__2d_8cpp.html#a7cee249cffcd5d7be1c31ea17a284cd9", null ],
    [ "set_values_struct", "fft__2d_8cpp.html#af439f7a9be2c4f5746d22bfecb527bdd", null ],
    [ "test_correctness", "fft__2d_8cpp.html#a50090af3f56c8a964b17ccd9ea6ba500", null ],
    [ "transpose", "fft__2d_8cpp.html#a0b36333131d10fd9a0abb3aa21b0b445", null ],
    [ "transpose_inplace", "fft__2d_8cpp.html#a4eb5cd8352d689f5495ec1ba1ea49f0a", null ],
    [ "EPS", "fft__2d_8cpp.html#af6f913fdc71ad35c8ec4d99fe8671987", null ]
];