var structviennacl_1_1scheduler_1_1result__of_1_1op__type__info_3_01op__vector__diag_01_4 =
[
    [ "id", "structviennacl_1_1scheduler_1_1result__of_1_1op__type__info_3_01op__vector__diag_01_4.html#a88aafafb79c0182adeeac7db46b92f90a456114e362731da2404b07665474ff68", null ],
    [ "family", "structviennacl_1_1scheduler_1_1result__of_1_1op__type__info_3_01op__vector__diag_01_4.html#a88aafafb79c0182adeeac7db46b92f90a767f11b0df7330d0dcfb0d1c20c8dc13", null ]
];