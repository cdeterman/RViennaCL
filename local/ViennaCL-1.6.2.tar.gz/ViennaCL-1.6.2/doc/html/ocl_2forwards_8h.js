var ocl_2forwards_8h =
[
    [ "gpu_tag", "structviennacl_1_1ocl_1_1gpu__tag.html", null ],
    [ "cpu_tag", "structviennacl_1_1ocl_1_1cpu__tag.html", null ],
    [ "accelerator_tag", "structviennacl_1_1ocl_1_1accelerator__tag.html", null ],
    [ "default_tag", "structviennacl_1_1ocl_1_1default__tag.html", null ],
    [ "handle", "classviennacl_1_1ocl_1_1handle.html", "classviennacl_1_1ocl_1_1handle" ],
    [ "VIENNACL_OCL_MAX_DEVICE_NUM", "ocl_2forwards_8h.html#a2d90eef0a67b2af2801368b3ab5b357f", null ],
    [ "current_context", "ocl_2forwards_8h.html#a16fc917445ce2010e7b16fbc968771b7", null ],
    [ "current_device", "ocl_2forwards_8h.html#ac54d59a74deaccec81f64e738b856348", null ],
    [ "enqueue", "ocl_2forwards_8h.html#a5f2022f653ea1cf364d20e3ff84dcada", null ]
];