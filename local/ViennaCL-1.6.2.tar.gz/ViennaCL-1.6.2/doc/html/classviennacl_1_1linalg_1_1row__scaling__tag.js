var classviennacl_1_1linalg_1_1row__scaling__tag =
[
    [ "row_scaling_tag", "classviennacl_1_1linalg_1_1row__scaling__tag.html#a3c3bfb1f173289eb5e5e8e91c59d4e7d", null ],
    [ "norm", "classviennacl_1_1linalg_1_1row__scaling__tag.html#aa53822390da5f7d7d497c71d706446d7", null ]
];