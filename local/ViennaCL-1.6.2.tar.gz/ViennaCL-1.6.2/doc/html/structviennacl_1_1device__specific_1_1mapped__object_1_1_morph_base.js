var structviennacl_1_1device__specific_1_1mapped__object_1_1_morph_base =
[
    [ "~MorphBase", "structviennacl_1_1device__specific_1_1mapped__object_1_1_morph_base.html#a12be18214880552ff3d1ec024ea80452", null ]
];