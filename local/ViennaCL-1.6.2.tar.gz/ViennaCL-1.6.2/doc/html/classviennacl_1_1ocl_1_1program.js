var classviennacl_1_1ocl_1_1program =
[
    [ "program", "classviennacl_1_1ocl_1_1program.html#aca261f14e968b1817329fd70feffc18f", null ],
    [ "program", "classviennacl_1_1ocl_1_1program.html#a200a9787e1bfcc1edd51e81afde01599", null ],
    [ "program", "classviennacl_1_1ocl_1_1program.html#a9ecf10d4388064be1b10aa69de63d648", null ],
    [ "add_kernel", "classviennacl_1_1ocl_1_1program.html#aa4f77fdcd02daa7d71627dc20117ba75", null ],
    [ "get_kernel", "classviennacl_1_1ocl_1_1program.html#a117eef2c7894ab1d794bc115d2a23f4a", null ],
    [ "handle", "classviennacl_1_1ocl_1_1program.html#a7c0474f0a8bbb734254d37905761ba77", null ],
    [ "name", "classviennacl_1_1ocl_1_1program.html#a956fa101a29331dba0ec621a95cfab28", null ],
    [ "operator=", "classviennacl_1_1ocl_1_1program.html#a108f2fd60c48c4d01fa8c706837aac16", null ],
    [ "p_context", "classviennacl_1_1ocl_1_1program.html#acd547941bc65e0a26eb2d6a9c3e4c29f", null ]
];