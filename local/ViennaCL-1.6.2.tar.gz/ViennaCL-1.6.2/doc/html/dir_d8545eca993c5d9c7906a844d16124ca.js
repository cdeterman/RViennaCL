var dir_d8545eca993c5d9c7906a844d16124ca =
[
    [ "benchmark-utils.hpp", "benchmark-utils_8hpp.html", "benchmark-utils_8hpp" ],
    [ "dense_blas.cpp", "dense__blas_8cpp.html", "dense__blas_8cpp" ],
    [ "direct_solve.cpp", "direct__solve_8cpp.html", "direct__solve_8cpp" ],
    [ "opencl.cpp", "opencl_8cpp.html", "opencl_8cpp" ],
    [ "qr.cpp", "benchmarks_2qr_8cpp.html", "benchmarks_2qr_8cpp" ],
    [ "scheduler.cpp", "benchmarks_2scheduler_8cpp.html", "benchmarks_2scheduler_8cpp" ],
    [ "solver.cpp", "solver_8cpp.html", "solver_8cpp" ],
    [ "sparse.cpp", "examples_2benchmarks_2sparse_8cpp.html", "examples_2benchmarks_2sparse_8cpp" ]
];