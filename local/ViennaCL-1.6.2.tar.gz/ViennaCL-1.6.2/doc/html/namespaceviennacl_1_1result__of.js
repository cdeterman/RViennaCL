var namespaceviennacl_1_1result__of =
[
    [ "alignment", "structviennacl_1_1result__of_1_1alignment.html", "structviennacl_1_1result__of_1_1alignment" ],
    [ "cl_type", "structviennacl_1_1result__of_1_1cl__type.html", "structviennacl_1_1result__of_1_1cl__type" ],
    [ "cpu_value_type", "structviennacl_1_1result__of_1_1cpu__value__type.html", "structviennacl_1_1result__of_1_1cpu__value__type" ],
    [ "size_type", "structviennacl_1_1result__of_1_1size__type.html", "structviennacl_1_1result__of_1_1size__type" ],
    [ "value_type", "structviennacl_1_1result__of_1_1value__type.html", "structviennacl_1_1result__of_1_1value__type" ]
];